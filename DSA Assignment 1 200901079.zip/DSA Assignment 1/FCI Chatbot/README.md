# FCI Chatbot

## Installation
1. install python 3.7.9 Windows x86 executable installer
2. install chatterbot [pip install chatterbot]
3. install spacy [pip install spacy==2.2] and  [python -m spacy download en]
4. install Flask 
5. install pandas
6. install flask_simplelogin
7. better_profanity



